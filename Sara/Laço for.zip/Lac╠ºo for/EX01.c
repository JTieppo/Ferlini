#include <stdio.h>
int main(){
    for (int num =2; num<=20; num +=2) {
        printf("%i\n", num);
    }
}

